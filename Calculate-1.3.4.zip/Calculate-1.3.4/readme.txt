----------Manual-----------
(I'm writing it now!)

This script is based on python
Please run calculate.py with python = =
So you must download python before using this script.
I am refining my script all the time,so if you have problem or find bugs, please download the latest version of the script .
If the latest version can't help you and you want to communicate with me , send e-mails to me.
-----------------------------------------------------
Main Menu
Option 1
If you want to use custom functional groups, please select option 1,.After that you will be able to create your personal element. 
Chemical formula input example: Cu(OH)2·6(H2O) Cu(OH)2(H2O)6
Please make sure to enclose functional groups in parentheses.