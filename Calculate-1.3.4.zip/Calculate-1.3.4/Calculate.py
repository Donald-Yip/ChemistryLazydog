import re
import shutil
import os
import time
from datetime import datetime

# Import custom_elements module
from custom_elements import custom_elements

# Import element_masses data
from element_masses import element_masses
from Default_setting import Default_liquid_concentration_unit, Default_solid_mass_unit, Default_liquid_concentration, Default_liquid_amount_unit, Default_liquid_amount, Default_solid_amount_unit, Default_solid_amount, Default_solid_chemical_fomula
from Default_setting import default_mass_in_grams_round, default_molecular_mass_round,default_original_molecular_mass_round
def makeline():
    print('-----------------------------------------------------------')

# Add custom elements to the custom_elements dictionary
def add_custom_element(element, mass, custom_elements):
    custom_elements[element] = float(mass)
    update_custom_elements_file(custom_elements)

# Delete a custom element from the custom_elements dictionary
def delete_custom_element(element, custom_elements):
    if element in custom_elements:
        del custom_elements[element]
        print(f"Custom element '{element}' deleted.")
    else:
        print(f"Custom element '{element}' not found.")
    update_custom_elements_file(custom_elements)

# Show all custom elements
def show_custom_elements(custom_elements):
    print('$------Custom Elements List------$')
    if custom_elements:
        print("Custom elements:")
        for element, mass in custom_elements.items():
            print(f"$  {element}: {mass}  $")
    else:
        print("$  No custom elements added now. $")
    print('$----------End of List-----------$')

# Update custom elements in the custom_elements.py file
def update_custom_elements_file(custom_elements):
    with open('custom_elements.py', 'w') as custom_elements_file:
        custom_elements_file.write(f'custom_elements = {custom_elements}')

custom_elements_file = 'custom_elements.py'

# If the custom_elements.py file exists, load custom elements from it
if os.path.exists(custom_elements_file):
    from custom_elements import custom_elements
else:
    custom_elements = {}

# Recursively parse chemical formulas, including custom elements and groups
def parse_chemical_formula(chemical_formula, custom_elements):
    def parse_group(group_formula):
        return parse_chemical_formula(group_formula, custom_elements)

    pattern = r'([A-Z][a-z]*)(\d*)|\(([^()]*)\)(\d*)|(@[A-Za-z]+\d*)|(\d+)\(([^()]*)\)|(\d+)([A-Z][a-z]*)'
    elements = re.findall(pattern, chemical_formula)

    atom_count = {}
    current_multiplier = 1

    for element, count, group, group_count, custom_element, group_multiplier, group_content, num_before_element, element_without_group in elements:
        if element:
            if current_multiplier == 1:
                atom_count[element] = atom_count.get(element, 0) + int(count or 1)
            else:
                atom_count[element] = atom_count.get(element, 0) + int(count or 1) * current_multiplier
        elif group:
            group_atom_count = parse_group(group)
            for atom, atom_count_in_group in group_atom_count.items():
                if current_multiplier == 1:
                    atom_count[atom] = atom_count.get(atom, 0) + atom_count_in_group * int(group_count or 1)
                else:
                    atom_count[atom] = atom_count.get(atom, 0) + atom_count_in_group * int(group_count or 1) * current_multiplier
        elif custom_element:
            custom_element_name = custom_element[1:]  # Remove the '@' symbol
            custom_element_mass = custom_elements.get(custom_element_name, None)
            if custom_element_mass is not None:
                atom_count[custom_element_name] = atom_count.get(custom_element_name, 0) + 1 * current_multiplier
            else:
                print(f"Custom element '{custom_element_name}' not found in the custom elements dictionary.")
        elif group_multiplier and group_content:
            group_count = int(group_multiplier)
            group_atom_count = parse_group(group_content)
            for atom, atom_count_in_group in group_atom_count.items():
                atom_count[atom] = atom_count.get(atom, 0) + atom_count_in_group * group_count
        elif num_before_element and element_without_group:
            num_count = int(num_before_element)
            if current_multiplier == 1:
                atom_count[element_without_group] = atom_count.get(element_without_group, 0) + num_count
            else:
                atom_count[element_without_group] = atom_count.get(element_without_group, 0) + num_count * current_multiplier
        else:
            current_multiplier = int(count or 1)

    return atom_count

# Calculate the molecular mass of a chemical formula
def calculate_molecular_mass(chemical_formula, custom_elements,mass_unit,amount_unit,amount):
    atom_count = parse_chemical_formula(chemical_formula, custom_elements)
    total_mass = 0
    mass_in_grams_round =default_mass_in_grams_round
    molecular_mass_round = default_molecular_mass_round
    original_molecular_mass_round=default_original_molecular_mass_round
    solid_conversions = {
        "kg": 0.001,
        "g": 1,
        "mg": 1000,
        "mmol": 0.001,
        "mol": 1,
    }
    for element, count in atom_count.items():
        if element in custom_elements:
            total_mass += custom_elements[element] * count
        elif element in element_masses:
            total_mass += element_masses[element] * count
        else:
            print(f"Element '{element}' not found in the mass dictionary.")
    print (total_mass)
    molecular_mass = total_mass
    original_molecular_mass = molecular_mass
    if mass_unit in solid_conversions:
        molecular_mass *= solid_conversions[mass_unit]
    kamount = amount

    if amount_unit in solid_conversions:
        amount *= solid_conversions[amount_unit]

    mass_in_grams = molecular_mass * amount
    mass_in_grams = round(mass_in_grams, mass_in_grams_round)

    molecular_mass = molecular_mass * amount / kamount
    molecular_mass = round(molecular_mass, molecular_mass_round)
    Molecular_mass_Density = f"{molecular_mass} {mass_unit}/{amount_unit}"
    Substance_mass = f"{mass_in_grams} {mass_unit}"

    original_molecular_mass = round(original_molecular_mass,original_molecular_mass_round)
    print(chemical_formula)
    print(f"Molecular mass: {original_molecular_mass}")
    print(f"Molecular mass (Density): {molecular_mass} {mass_unit}/{amount_unit}")
    print(f"Substance mass: {mass_in_grams} {mass_unit}")
    return original_molecular_mass,Molecular_mass_Density,Substance_mass

def calculate_volume(concentration_unit, concentration, amount_unit, amount):
    conversion_factors = {
        "mmol/L": 1000,  # Default conversion factor
        "mol/L": 1,
        "mol/mL": 0.001,
        "mol": 1.0,     # Default conversion factor
        "mmol": 0.001,
    }

    if concentration_unit in conversion_factors:
        concentration_conversion = conversion_factors[concentration_unit]
    else:
        print(f"Unknown concentration unit: {concentration_unit}")
        return

    if amount_unit in conversion_factors:
        amount_conversion = conversion_factors[amount_unit]
    else:
        print(f"Unknown amount unit: {amount_unit}")
        return

    amount_mol = amount  # No conversion needed
    volume = amount_mol / concentration
    volume *= concentration_conversion
    volume *= amount_conversion

    print(f"Required volume: {volume} mL")

def process_formula_file(file_path, custom_elements, current_directory, mass_unit, amount_unit):
    while True:
        if file_path == '':
            real_file_path = os.path.join(current_directory, 'calculation.txt')
        else:
            real_file_path = file_path

        try:
            with open(real_file_path, 'r') as file:
                lines = file.readlines()

            # 寻找formula关键字的起始和结束行
            start_line = None
            end_line = None


            for i, line in enumerate(lines):
                if line.strip() == 'Formula_Solid':
                    start_line = i + 1
                elif line.strip() == 'End_Formula_Solid':
                    end_line = i
                    break


                    
            if start_line is None or end_line is None:
                print("Invalid file format. 'Formula Solid' or 'End Formula Solid' keywords not found.")
                break

            formulas = []
            for line in lines[start_line:end_line]:
                words = re.split(r'\s+(?![^(]*\))', line.strip())
                print(len(words))
                formula = words[0]
                if len(words) == 2:
                    
                    
                    amount = float(words[1])
                    original_molecular_mass, _, mass = calculate_molecular_mass(formula, custom_elements, mass_unit, amount_unit, amount)
                    formulas.append((formula, original_molecular_mass,amount, mass))
                if len(words) >= 3:
                    
                    amount = float(words[2])
                    original_molecular_mass, _, mass = calculate_molecular_mass(formula, custom_elements, mass_unit, amount_unit, amount)
                    formulas.append((formula, original_molecular_mass,amount, mass))
                else:
                    print("Invalid formula format. Skipping line:", line.strip())

            # 修改第三个词所在的行
            for i, line in enumerate(lines[start_line:end_line]):
                if len(line.strip().split()) >= 2:
                    words = line.strip().split()
                    formula = words[0]
                    amount = float(words[1])
                    if len(words) >= 2:
                        del words[1:]
                    mass = formulas[i][3]
                    amount = formulas[i][2]
                    omm = formulas[i][1] #original_molecular_mass 
                    words.append(str(omm))
                    words.append(str(amount))
                    words.append(str(mass))
                    lines[start_line + i] = ' '.join(words) + '\n'

            # 重写文件
            with open(real_file_path, 'w') as file:
                file.writelines(lines)
            break

        except FileNotFoundError:
            print("File not found. Please enter a valid file path.")
            file_path = input("Enter the file path: ")



def merge_PL_data(folder_path):
    folder_path = folder_path.strip('"')
    wavelength_unit = "nm"
    all_data = []
    found_valid_file = False  # 判断是否找到符合要求的文件

    txt_files = [file for file in os.listdir(folder_path) if file.endswith('.txt')]
    for txt_file in txt_files:
        file_path = os.path.join(folder_path, txt_file)
        with open(file_path, 'r') as original_file:
            lines = original_file.readlines()

            xaxis_line = [line for line in lines if line.startswith('Xaxis,')]
            yaxis_line = [line for line in lines if line.startswith('Yaxis,')]
            fix_line = [line for line in lines if line.startswith('Fixed/Offset,')]
            start_line = [line for line in lines if line.startswith('Start,')]
            stop_line = [line for line in lines if line.startswith('Stop,')]
            detector_index = -1
            for i, line in enumerate(lines):
                if line.startswith('Detector'):
                    detector_index = i
                    break

            if not (xaxis_line and yaxis_line and fix_line and start_line and stop_line and detector_index != -1):
                continue  # 如果没有找到任一关键字，则跳过处理这个文件

            found_valid_file = True  # 找到符合要求的文件

            data_row = []

            xaxis_parts = xaxis_line[0].split(',')
            yaxis_parts = yaxis_line[0].split(',')
            Xaxis = xaxis_parts[1].strip()
            Yaxis = yaxis_parts[1].strip()
            combind = f"{Xaxis},{Yaxis}"
            data_row.append(combind)

            fix_parts = fix_line[0].split(',')
            FIX_NUMBER = float(fix_parts[1])

            start_parts = start_line[0].split(',')
            stop_parts = stop_line[0].split(',')
            START_NUMBER = float(start_parts[1])
            STOP_NUMBER = float(stop_parts[1])

            if FIX_NUMBER < START_NUMBER:
                data_row.append(f"{wavelength_unit},")
                data_row.append(f",EX@{FIX_NUMBER}nm")
            elif FIX_NUMBER > STOP_NUMBER:
                data_row.append(f"{wavelength_unit},")
                data_row.append(f",EM@{FIX_NUMBER}nm")

            if detector_index != -1:
                detector_data = []
                for line in lines[detector_index + 2:]:
                    detector_data.append(line.strip().rstrip(','))
                data_row.extend(detector_data)

            all_data.append(data_row)

    if not found_valid_file:
        print("没有符合要求的文件，请检查文件内容是否满足要求。")
        return

    max_columns = max(len(row) for row in all_data)

    merged_data = []
    for i in range(max_columns):
        merged_column = []
        for row in all_data:
            if i < len(row):
                merged_column.extend(row[i].split(','))
            else:
                merged_column.extend([''] * len(row[0].split(',')))
        merged_data.append(','.join(merged_column))

    with open(os.path.join(folder_path, 'PL.txt'), 'w') as pl_file:
        pl_file.write('\n'.join(merged_data))
    makeline()
    print("Done!Now you can check the merged PL.txt file and  separate data in Excel using commas(,) and spaces( ) .")
    print("整理完成，现在您可以查看合并后的PL.txt文件，并使用逗号（,)和空格（ ）将数据分开。")
    print("when you seperate data, please do not choose the option 'Treat consecutive delimiters as one'.")
    print("当你分列时，请不要勾选'连续的分隔符被视为单个分隔符'选项。")
    makeline()
    





if __name__ == "__main__": 
    print('-----------------------------------------------------------')
    print("Current Time: " + datetime.now().strftime("%Y-%m-%d %H:%M:S"))
    print("Welcome to Calculate! The script was written by Donald Yip\nI always try to make it as easy as possible to use and as romantic as possible to look like!")
    mylovedlyric = 'A KISS IS STILL A KISS IN CASABLANCA ,BUT A KISS IS NOT A KISS WITHOUT YOUR SIGH !'
    print("My lovely lyric: " + mylovedlyric)

    while True:
        #Main Menu
        print("---------------------Main Menu---------------------")
        print("1. Manage Custom Elements (a: add, d: delete)")
        print("2. Calculate Mass or Volume")
        print("3. Show Custom Elements")
        print("4. Merge PL data")
        print("q. Exit elegently now")
        makeline()
        choice = input("Enter your choice: ")
        makeline()

        if choice == "1": #Main Menu/option 1 : add or delete custom elements
            print ('current custom elements:')
            show_custom_elements(custom_elements)
            manage_custom_elements_choice = input("Choose (a) to add custom element or (d) to delete custom element: ").lower()
            
            if manage_custom_elements_choice == "a": #Main Menu/option 1/option a: add custom element
                element_data = 'None'
                mass = 'None'
                while True :
                    element = ''
                    makeline()
                    print(f"1.add custom element, curent name of adding element:{element_data}")
                    print(f"2.add the mass of your custom element, curent mass of adding element:{mass}")
                    print('3.add custom element now! after adding, your current data of custom elements will be saved in custom_elements.py')
                    print(f"q.exit,this option will clear your current data of custom elements and return")
                    makeline()
                    localchoice = input("Enter your choice: ")
                    makeline()
                    if localchoice == '1':  #Main Menu/option 1/option a/option 1: add name of custom element
                        while True:
                            element_data = input("Enter the custom element and its mass (e.g.,Gua):  ")
                            if element_data == '':
                                print("Invalid input. Please try again.")
                                continue
                            else:
                                break
                    elif localchoice == '2': #Main Menu/option 1/option a/option 2: add mass of custom element
                        while True:
                            mass = input("Enter the mass of your custom element (e.g.3.5867):  ")
                            if mass == '':
                                print("Invalid input. Please try again.")
                                continue
                            else:
                                break
                    elif localchoice == '3': #Main Menu/option 1/option a/option 3: add custom element
                        add_custom_element(element_data, mass, custom_elements)
                        show_custom_elements(custom_elements)
                        element_data = 'None'
                        mass = 'None'
                        break
                    elif localchoice == 'q': #Main Menu/option 1/option a/option q: exit
                        element_data = 'None'
                        mass = 'None'
                        break
                    else:
                        print("Invalid choice. Please try again.")

            elif manage_custom_elements_choice == "d": #Main Menu/option 1/option d: delete custom element
                element_to_delete = 'None'
                while True:
                    print(f"1.curent name of deleting element:  {element_to_delete}")
                    print("2.delete custom element now! after deleting, your changed data will be saved in custom_elements.py")
                    print("q.exit,this option will clear your current data of this deleting custom elements and return")
                    makeline()
                    localchoice = input("Enter your choice: ")
                    makeline()
                    if localchoice == '1': #Main Menu/option 1/option d/option 1: delete name of custom element
                        while True:
                            element_to_delete = input("Enter the custom element to delete (e.g.,Gua): ")
                            if element_to_delete == '':
                                print("Invalid input. Please try again.")
                                continue
                            else:
                                break
                    elif localchoice == '2': #Main Menu/option 1/option d/option 2: delete custom element
                        delete_custom_element(element_to_delete, custom_elements)
                        show_custom_elements(custom_elements)
                        element_to_delete = 'None'
                        break
                    elif localchoice == 'q': #Main Menu/option 1/option d/option q: exit
                        element_to_delete = 'None'
                        break
        elif choice == "2": #Main Menu/option 2 : calculate mass or volume
            substance_type = input("Choose substance type (Enter for solid, 1 for liquid): ")
            makeline()
            if substance_type == "1": #Main Menu/option 2/option 1 : calculate liquid
                concentration_unit = Default_liquid_concentration_unit
                concentration = Default_liquid_concentration
                amount_unit = Default_liquid_amount_unit
                amount = Default_liquid_amount
                while True:
                    makeline()
                    print(f"1.Enter concentration unit, current unit is : {concentration_unit}")
                    print(f"2.Enter concentration, current concentration is : {concentration}")
                    print(f"3.Enter amount unit, current unit is : {amount_unit}")
                    print(f"4.Enter amount, current amount is : {amount}")
                    print("5.calculate the required volume now!")
                    print("q.exit,this option will return and not clear current data")
                    makeline()
                    localchoice = input("Enter your choice: ")
                    makeline()
                    if localchoice == '1': #Main Menu/option 2/option 1/option 1: enter concentration unit
                        concentration_unit_list = ['mol/L', 'mmol/L', 'mol/mL']
                        options = {}

                        while True:
                            prompt_message = "Enter concentration unit ("

                            for i, unit in enumerate(concentration_unit_list, start=1):
                                prompt_message += f"{i} for {unit}"
                                options[str(i)] = unit
                                if i < len(concentration_unit_list):
                                    prompt_message += ", "
                            prompt_message += "): "

                            concentration_unit_choice = input(prompt_message)

                            if concentration_unit_choice in options:
                                concentration_unit = options[concentration_unit_choice]
                                break
                            else:
                                print("Invalid input. Please try again.")
                    elif localchoice == '2': #Main Menu/option 2/option 1/option 2: enter concentration
                        while True:
                            concentration = float(input("Enter concentration: "))
                            if concentration == '':
                                print("Invalid input. Please try again.")
                                continue
                            else:
                                break
                    elif localchoice == '3': #Main Menu/option 2/option 1/option 3: enter amount unit
                        while True:
                            prompt_message = "Enter the unit for the required amount of substance ("
                            options = {}

                            amount_unit_list = ['mmol', 'mol']

                            for i, unit in enumerate(amount_unit_list, start=1):
                                choice = str(i)
                                prompt_message += f"{choice} for {unit}"
                                options[choice] = unit
                                if i < len(amount_unit_list):
                                    prompt_message += ", "
                            prompt_message += "): "
                            amount_unit_choice = input(prompt_message)

                            if amount_unit_choice in options:
                                amount_unit = options[amount_unit_choice]
                                break
                            else:
                                print("Invalid input. Please try again.")
                    elif localchoice == '4': #Main Menu/option 2/option 1/option 4: enter amount
                        while True:
                            amount = float(input("Enter the required amount of substance: "))
                            if amount == '':
                                print("Invalid input. Please try again.")
                                continue
                            else:
                                break
                    elif localchoice == '5': #Main Menu/option 2/option 1/option 5: calculate the required volume
                        print(f"{concentration_unit, concentration, amount_unit, amount}")
                        calculate_volume(concentration_unit, concentration, amount_unit, amount)
                        break
                    elif localchoice == 'q': #Main Menu/option 2/option 1/option q: exit
                        break
                    else:
                        print("Invalid input. Please try again.")
            elif substance_type == "": #Main Menu/option 2/option 2 : calculate solid
                chemical_formula = Default_solid_chemical_fomula
                mass_unit = Default_solid_mass_unit
                amount_unit = Default_solid_amount_unit
                amount = Default_solid_amount   
                while True:
                    makeline()
                    print(f"1. Enter chemical formula, current formula is:   {chemical_formula}")
                    print(f"2. Enter mass unit, current unit is:   {mass_unit}")
                    print(f"3. Enter amount unit, current unit is:   {amount_unit}")
                    print(f"4. Enter amount, current amount is:   {amount}")
                    print(f"5.Enter isotopes,notice! if you choose this option, all atoms of one element which is changed\nin the formula will be replaced by the new data at this time.They will be listed below ")
                    print("6. calculate the molecular mass now!")
                    print("7. calculate from txt!")
                    print("q. exit,this option will return and not clear current data")
                    print(f"###  NOTICE! The elements (include isotopes and custom elements) which have been changed are:  ###\n {custom_elements}")
                    makeline()
                    localchoice = input("Enter your choice: ")
                    makeline()
                    if localchoice == '1': #Main Menu/option 2/option 2/option 1: enter chemical formula
                        while True:
                            chemical_formula = input("Enter the chemical formula,e.g., Cu(OH)2·6(H2O) ,Cu(OH)2(H2O)6: ")
                            if chemical_formula == '':
                                print("Invalid input. Please try again.")
                                continue
                            else:
                                break
                    elif localchoice == '2': #Main Menu/option 2/option 2/option 2: enter mass unit
                        while True:
                            prompt_message = "Enter the mass unit ("
                            options = {}

                            unit_choices = ['mg', 'g', 'kg']

                            for i, unit in enumerate(unit_choices, start=1):
                                choice = str(i)
                                prompt_message += f"{choice} for {unit}"
                                options[choice] = unit
                                if i < len(unit_choices):
                                    prompt_message += ", "
                            prompt_message += "): "

                            mass_unit_choice = input(prompt_message)

                            if mass_unit_choice in options:
                                mass_unit = options[mass_unit_choice]
                                break
                            else:
                                print("Invalid input. Please try again.")

                    elif localchoice == '3': #Main Menu/option 2/option 2/option 3: enter amount unit
                        while True:
                            prompt_message = "Enter the unit for the required amount of substance ("
                            options = {}

                            unit_choices = ['mmol', 'mol']

                            for i, unit in enumerate(unit_choices, start=1):
                                choice = str(i)
                                prompt_message += f"{choice} for {unit}"
                                options[choice] = unit
                                if i < len(unit_choices):
                                    prompt_message += ", "
                            prompt_message += "): "

                            amount_unit_choice = input(prompt_message)

                            if amount_unit_choice in options:
                                amount_unit = options[amount_unit_choice]
                                break
                            else:
                                print("Invalid input. Please try again.")

                    elif localchoice == '4': #Main Menu/option 2/option 2/option 4: enter amount
                        while True:
                            amount = float(input("Enter the required amount of substance : "))
                            if amount == '':
                                print("Invalid input. Please try again.")
                                continue
                            else:
                                break
                    elif localchoice == '5': #Main Menu/option 2/option 2/option 5: enter isotopes
                        isotope_input = input("Do you need to specify isotope masses for elements? (1 for yes, 2 for no): ")
                        if isotope_input == '1':
                            isotopes = input("Enter element symbol and isotope mass, formatted as 'Element/Mass' (separated by a space), press Enter for the next element, or press Enter to finish: ")
                            while isotopes:
                                isotope_elements = isotopes.split()
                                for element in isotope_elements:
                                    isotope_element, mass = element.split("/")
                                    custom_elements[isotope_element] = float(mass)
                                isotopes = input("Press Enter for the next element, or press Enter to finish: ")
                    elif localchoice == '6': #Main Menu/option 2/option 2/option 6: calculate the molecular mass
                        original_molecular_mass,Molecular_mass_Density,Substance_mass = calculate_molecular_mass(chemical_formula, custom_elements,mass_unit,amount_unit,amount)
                        print("Whether save the result as a custom element or not?")
                        savechoice = input("Enter for yes, 1 for no: ")
                        if savechoice == '':
                            savename = 'None'
                            while True:
                                print(f"The mass of the element or group is {original_molecular_mass}")
                                print(f"Enter name of the element or group, current name :  {savename}")
                                savename = input("Please name it: ")
                                add_custom_element(savename, original_molecular_mass, custom_elements)
                                show_custom_elements(custom_elements)
                                break
                            break
                        elif savechoice == '1':
                            break
                    elif localchoice == '7': #Main Menu/option 2/option 2/option 7: calculate from txt
                        current_directory = os.path.dirname(os.path.abspath(__file__))
                        file_path = input("Enter the path of the txt file, if you press enter directly, \nthe default file (calculation.txt) will be used: ")
                        process_formula_file(file_path, custom_elements,current_directory,mass_unit,amount_unit)
                    elif localchoice == 'q': #Main Menu/option 2/option 2/option q: exit
                        break
                    else:
                        print("Invalid input. Please try again.")
        elif choice == "3": #Main Menu/option 3: show custom elements
            show_custom_elements(custom_elements)
        elif choice == "4": #Main Menu/option 4: Merge PL data
            print("make sure you have at least one complete xx.txt which is about PL in the folder you want to merge")
            folder_path = input("Enter the path of the folder containing the PL data files,e.g. C:\\Users\\User\\Desktop\\folder:\n")
            if os.path.exists(folder_path):
                makeline()
                print("your folder exists: ", folder_path,"then you can find PL.txt in it")
                makeline()
                merge_PL_data(folder_path)
            else:
                print("no such folder")
        elif choice == "q": #Main Menu/option q: exit
            print("I LOVE YOU MORE AND MORE EACH DAY AS TIME GOES BY")
            time.sleep(3) 
            break
        else:
            print("Invalid choice. Please choose a valid option (1, 2, 3, or q).")

    try:
        shutil.rmtree('__pycache__')
    except FileNotFoundError:
        pass
