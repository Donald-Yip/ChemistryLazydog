Please run calculate.py with pytjon = =
If you want to use custom functional groups, please select option 1.
Chemical formula input example: Cu(OH)2·6(H2O) Cu(OH)2(H2O)6
Please make sure to enclose functional groups in parentheses.