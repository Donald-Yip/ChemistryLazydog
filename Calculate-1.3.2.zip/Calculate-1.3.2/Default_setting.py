#Here you can change all of default setting in this script
#######################################################################
#main manu option 2//liqued module 
Default_liquid_concentration_unit = 'mol/mL'    #unit of concentration
Default_liquid_concentration = 1.0
Default_liquid_amount_unit = 'mol'      #unit of amount
Default_liquid_amount = 1.0

#main manu option 2//solid module
Default_solid_chemical_fomula = 'None'
Default_solid_mass_unit = 'g'   #unit of mass
Default_solid_amount_unit = 'mmol'      #unit of amount 
Default_solid_amount = 1.0      

#function // calculate_molecular_mass
    #Here you can change variables of result
default_mass_in_grams_round=4     #four decimal places
default_molecular_mass_round=4     #four decimal places
default_original_molecular_mass_round=3    #three decimal places


