import requests
from bs4 import BeautifulSoup
from googletrans import Translator

# 定义要搜索的关键字
search_keyword = "perovskite"

# 设置搜索引擎地址
search_url = f"https://www.x-mol.com/paper/search/q?option={search_keyword}"
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36 Edg/118.0.2088.76'
}
response = requests.get(search_url, headers=headers)
bsObj = BeautifulSoup(response.text, 'lxml')
print(bsObj)
# 发送HTTP请求并获取页面内容

# 检查是否成功获取页面
# if response.status_code == 200:
#     print("页面获取成功")# 使用BeautifulSoup解析页面内容
#     soup = BeautifulSoup(response.text, 'html.parser')

#     # 获取文献标题、摘要和关键字
#     titles = [title.text for title in soup.find_all('h2', class_='title-class')]
#     abstracts = [abstract.text for abstract in soup.find_all('p', class_='abstract-class')]
#     keywords = [keyword.text for keyword in soup.find_all('span', class_='keyword-class')]

#     # 创建一个翻译器
#     translator = Translator()

#     # 将英文翻译成中文
#     titles_translated = [translator.translate(title, src='en', dest='zh-cn').text for title in titles]
#     abstracts_translated = [translator.translate(abstract, src='en', dest='zh-cn').text for abstract in abstracts]
#     keywords_translated = [translator.translate(keyword, src='en', dest='zh-cn').text for keyword in keywords]

#     # 打印结果
#     for i in range(len(titles_translated)):
#         print(f"标题：{titles_translated[i]}")
#         print(f"摘要：{abstracts_translated[i]}")
#         print(f"关键字：{keywords_translated[i]}")
#         print("\n")

# else:
#     print(f"无法访问页面，状态码：{response.status_code}")
